class SearchPage{

    searchQuery(input){

       cy.visit("http://localhost:3001");
       cy.get('.w-full').type(input);
       cy.get('.px-6').click();


    }


}

export default SearchPage;