import SearchPage from "../pages/SearchPage"
describe("Testing Search functionality",()=>{

    const searchPage= new SearchPage();
    
    it("Test Case 1:Testing with valid input",()=>{

        searchPage.searchQuery("Data Protection and Privacy Act");
        cy.get('.bg-white > .text-slate-600').should("have.text","This act establishes the rules for collecting, storing, and processing personal data. Organizations must ensure data security and comply with consent requirements.");
        cy.get('.w-full').clear();
    })


   it("Test Case 2: Testing with wrong input",()=>{

        searchPage.searchQuery("1234");
        cy.get('.mt-8 > .text-slate-600').should("have.text",'No documents found matching "1234". Try a different search term.');
    })
    
    it("Test Case 3: Testing with partial text",()=>{

       searchPage.searchQuery("pro"); 
       cy.get('.text-slate-700 > .font-semibold').should("have.text",'Found 5 relevant legal document(s): Data Protection and Privacy Act, Intellectual Property Rights Law, Consumer Protection Regulations, Cybersecurity Framework, Intellectual Property Licensing Agreement Template.');
    })

    

})